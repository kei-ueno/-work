package card_game;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class BlackjackMain {
	public static void main(String[] args) {//main

		System.out.println("ゲームを開始します");
		//空の山札を作成
		List<Integer> deck = new ArrayList<>(52);
		//山札をシャッフル
		Deck.shuffleDeck(deck);

		//プレイヤー・ディーラーの手札リストを生成
		List<Integer> player = new ArrayList<>();//プレイヤーの手札リスト
		List<Integer> dealer = new ArrayList<>();//ディーラーの手札リスト

		//プレイヤー・ディーラーがカードを2枚引く[交互にひく]
		player.add(deck.get(0));
		dealer.add(deck.get(1));
		player.add(deck.get(2));
		dealer.add(deck.get(3));

		//山札の進行状況を記録する変数deckCountを定義
		int deckCount = 4;

		//プレイヤーの手札枚数を記録する変数playerHandsを定義
		int playerHands = 2;

		//宣言修了メインの↑に処理メソッド作成

		//プレイヤー・ディーラーの手札のポイントを表示
		System.out.println("あなたの1枚目のカードは" + Deck.toDescription(player.get(0)));//カードの置き換えて表示（置き換えメソッド必要

		System.out.println("ディーラーの1枚目のカードは" + Deck.toDescription(dealer.get(0)));

		System.out.println("あなたの2枚めのカードは" + Deck.toDescription(player.get(1)));

		System.out.println("ディーラーの2枚めのカードは秘密です。");

		//プレイヤー・ディーラーのポイントを集計
		int playerPoint = Blackjack.sumPoint(player);
		int dealerPoint = Blackjack.sumPoint(dealer);

		System.out.println("あなたの現在のポイントは" + playerPoint + "です。");

		//プレイヤーがカードを引くフェーズ
		while (true) {
			System.out.println("カードを引きますか？Yes:y or No:n");
			Scanner scan = new Scanner(System.in);
			String str = scan.next();

			if ("n".equals(str)) {
				break;
			} else if ("y".equals(str)) {
				//手札に山札から1枚加える
				player.add(deck.get(deckCount));
				//山札と手札を一枚進める
				deckCount++;
				playerHands++;

				System.out.println("あなたの" + playerHands + "枚目のカードは" + Deck.toDescription(player.get(playerHands - 1)));
				playerPoint = Blackjack.sumPoint(player);
				System.out.println("現在の合計は" + playerPoint);
				//プレイヤーのバーストチェック
				if (Blackjack.isBusted(playerPoint)) {
					System.out.println("残念、バーストしてしまいました。");
					return;
				}
			} else {
				System.out.println("あなたの入力は" + str + " です。y か n を入力してください。");
			}
		}

		//ディーラーが手札を17以上にするまでカードを引くフェーズ
		while (true) {
			//手札が17以上の場合ブレーク
			if (dealerPoint >= 17) {
				break;
			} else {
				//手札に山札から1枚加える
				dealer.add(deck.get(deckCount));
				//山札を一枚進める
				deckCount++;

				//ディーラーの合計ポイントを計算
				dealerPoint = Blackjack.sumPoint(dealer);
				//ディーラーのバーストチェック
				if (Blackjack.isBusted(dealerPoint)) {
					System.out.println("ディーラーがバーストしました。あなたの勝ちです！");
					return;
				}

			}

		}
		//合計表示
		System.out.println("あなたのポイントは" + playerPoint);
		System.out.println("ディーラーのポイントは" + dealerPoint);
		//勝ち負け判定
		if (playerPoint == dealerPoint) {
			System.out.println("引き分けです。");
		} else if (playerPoint > dealerPoint) {
			System.out.println("勝ちました！");
		} else {
			System.out.println("負けました・・・");
		}

	}

}
