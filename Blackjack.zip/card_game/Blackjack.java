package card_game;

import java.util.List;

public class Blackjack {
	public static int toPoint(int num) {
		if (num == 11 || num == 12 || num == 13) {
			num = 10;
		}

		return num;
	}

	//現在の合計ポイントを計算するメソッド
	public static int sumPoint(List<Integer> list) {
		int sum = 0;

		for (int i = 0; i < list.size(); i++) {
			sum = sum + toPoint(Deck.toNumber(list.get(i)));
		}

		return sum;
	}

	//手札がバーストしているか判定するメソッド
	public static boolean isBusted(int point) {
		if (point <= 21) {
			return false;
		} else {
			return true;
		}
	}

}
